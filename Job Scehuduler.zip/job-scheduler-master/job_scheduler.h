/*
Author: Eric Latham
Email: ericoliverlatham@gmail.com
*/

void *complete_job(void *arg);
void *complete_jobs(void *arg);
void handle_input();
